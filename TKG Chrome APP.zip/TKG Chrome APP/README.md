# TKG Chrome App
Chrome App for [TMK Keymap Generator](http://tkg.io) ([source code](https://github.com/kairyu/tkg)).

<a target="_blank" href="https://chrome.google.com/webstore/detail/tkg-chrome-app/kmbmjdabhpdnpeobnbdchihdcdaccidi"><img alt="Try it now" src="https://raw.github.com/GoogleChrome/chrome-app-samples/master/tryitnowbutton_small.png" title="Click here to install this sample from the Chrome Web Store"></img></a>
